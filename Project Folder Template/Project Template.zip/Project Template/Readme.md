# Guidlines #

Bitte immer die Development Guidlines beachten: https://github.com/bluehands/development-guidelines

# Projektstruktur #

Ein Projekt besteht aus mehr als nur die Quellen. Alle verschiedene Artefakte sollen ihren Platz finden.

* 01 Ideas & Concepts   
* 02 Design
  * Code & Architecture
  * UI
* 03 Code
  * Prototypes (Kleine Projekte, um etwas auszuprobieren)
  * Source 
  * Tools (Projekte, um die Quellen zu bauen)
* 04 Review
  * Code
  * Design
* 05 Test
  * Integration Testing
  * Unit Testing
* 06 Documentation
  * Legal & Licences (U.a. alles was mit den Lizenzen der verwendeten Bibliotheken zu tun hat)
  * Technical Documentation
  * User Documentation 
* 07 Sample Data
* 10 Project Management
  * Meetings

  
